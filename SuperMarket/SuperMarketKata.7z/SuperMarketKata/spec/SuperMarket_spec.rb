require_relative '../SuperMarket.rb'
require 'rspec'

describe SuperMarket do

  before :each do
    @cart = SuperMarket.new
  end

  it 'will return $3.50 with 1 bread, noodles, and coup can' do
      @cart.calculateCost(1,1,1).should == 3.5
  end

end