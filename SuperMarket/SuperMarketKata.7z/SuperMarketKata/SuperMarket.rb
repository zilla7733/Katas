
class SuperMarket

  def initialize
    #Initialize goes here
    #You either have the option of passing in the values when calling the function
    #or you can initialize them when you create the object.
  end

  def calculateCost(bread, noodles, soupCans)
    #Code goes here
    return 0
  end

end
