require './gilded_rose.rb'
require "rspec"

describe GildedRose do

  let(:dexterity_vest) { dexterity_vest = subject.instance_variable_get(:@items)[0] }

  it "should decrease the sell-in date of the dexterity vest" do
    initial_sell_in = dexterity_vest.sell_in
    subject.update_quality
    dexterity_vest.sell_in.should == initial_sell_in - 2
  end

end